# project > urls.py
from django.urls import path
from . import views
urlpatterns=[
    path('hydrogencar.html',views.chart),
    path('profile.html',views.empty),
    path('home.html',views.form),
    path('',views.form),
    path('recommend.html',views.index),
    path('location.html',views.tab_panel),
    path('news.html',views.news),
    path('seoul.html',views.ui_elements),
]