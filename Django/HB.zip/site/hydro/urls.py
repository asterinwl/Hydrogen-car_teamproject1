from django.urls import path
from hydro import views

app_name ='hydro'

urlpatterns = [
    path('', views.index),
]