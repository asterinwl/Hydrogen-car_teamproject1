from django.shortcuts import render
# from django.http import HttpResponse

# Create your views here.
def index(request):
    """
    hydro 출력
    """
    # return HttpResponse('메인 페이지 예정')
    return render(request, 'hydro/hydro.html')